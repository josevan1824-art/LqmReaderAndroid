# LqmReader (Android WebView + GitHub Actions)

## Como gerar o APK automaticamente (GitHub Actions)
1) Crie um repositório no GitHub (ex.: `lqmreader-android`).
2) Faça upload de todos os arquivos desta pasta para a branch `main`.
3) Vá na aba **Actions** e ative os workflows (se aparecer um aviso).
4) A cada push na `main`, a Action **Android APK (assembleDebug)** vai compilar.
5) Ao terminar, vá em **Actions → run mais recente → Artifacts** e baixe `app-debug-apk`.

## Assinar APK para Release (opcional)
- Adicione os secrets no repo: `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`.
- Posso te fornecer um workflow `release.yml` que gera e anexa um APK assinado aos Releases.

## Build local (Android Studio)
- Abra a pasta no Android Studio (Java 17, SDK 34).
- Build > Build APK(s). O APK sai em `app/build/outputs/apk/debug`.

O app carrega `file:///android_asset/index.html`, que contém o leitor ZIP → LQM → Texto.
